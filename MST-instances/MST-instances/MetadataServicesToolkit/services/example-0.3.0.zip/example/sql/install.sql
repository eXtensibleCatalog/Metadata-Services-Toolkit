create table foos (
	foo_id          int          not null      AUTO_INCREMENT,
	foo             varchar(255),
	PRIMARY KEY (foo_id)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

